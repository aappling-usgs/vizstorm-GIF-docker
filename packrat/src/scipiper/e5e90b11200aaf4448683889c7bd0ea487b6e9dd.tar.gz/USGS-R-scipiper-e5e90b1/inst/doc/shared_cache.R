## ----setup, include=FALSE------------------------------------------------
knitr::opts_chunk$set(echo = TRUE, cache=FALSE, collapse=TRUE)
knitr::opts_knit$set(root.dir = tempdir())

## ----libs, message=FALSE-------------------------------------------------
library(scipiper)
library(dplyr)

