library(testthat)
test_check('geoknife')