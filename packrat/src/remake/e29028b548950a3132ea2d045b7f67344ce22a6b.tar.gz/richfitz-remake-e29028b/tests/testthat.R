library(testthat)
library(remake)

test_check("remake")
