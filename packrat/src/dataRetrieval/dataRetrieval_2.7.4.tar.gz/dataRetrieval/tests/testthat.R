library(testthat)
library(dataRetrieval)
test_check("dataRetrieval")
